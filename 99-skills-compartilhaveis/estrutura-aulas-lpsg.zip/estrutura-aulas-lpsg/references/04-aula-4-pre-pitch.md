# Aula 4 — Pré-pitch · 100% sobre o produto (criar desejo)

> **Mudança de natureza (decisão Léo · 2026-05-21):** a Aula 4 **não é mais a "aula técnica de otimização"**. Ela é o **pré-pitch do modelo 5+1**: uma aula **100% sobre o produto** cuja única missão é fazer a pessoa **sair desejando** o produto que será vendido no domingo (Aula 6). **NÃO fala preço. NÃO fala bônus.** Abre a ficha de interesse pra medir quem quer.

## 🏷️ Título público

**Fórmula:** `Aula 4 - {CHAMADA_QUE_PROMETE_O_SALTO_QUE_O_PRODUTO_ENTREGA} | {SIGLA}`

**Padrão da chamada:** promete o **salto / a aceleração** que o produto materializa, sem entregar que é dia de venda. A pessoa precisa querer assistir achando que é conteúdo · e sair desejando o produto.

**Exemplos:**
- `Aula 4 - O atalho que transforma 6 meses de trabalho em 7 dias | LPSG`
- `Aula 4 - Como sair do "fazendo sozinho" pro "rodando com a gente do lado" | DESAFIO 5KG`
- `Aula 4 - O caminho de quem não quer mais tentar na tentativa e erro | TRADE TURBO`

> O título nunca diz "hoje é venda". Diz "hoje eu te mostro pra onde tudo isso leva". O desejo se constrói durante a aula.

---

## Metadados

| Campo | Valor |
|---|---|
| **Dia** | {DIA_AULA_4} · {HORARIO_AULAS_SEMANA} |
| **Duração** | 40-50 min |
| **Posição na escada** | 4/6 |
| **Função** | **PRÉ-PITCH · 100% produto · criar DESEJO + abrir ficha de interesse** |
| **Marco** | Marco de desejo ("eu quero isso") |
| **Trava** | **SEM preço · SEM bônus** (tudo isso só no domingo, Aula 6) |

---

## 🎯 Objetivo estratégico

**Um objetivo central, inegociável:** fazer a pessoa **sair desta aula desejando o produto** que será ofertado no domingo.

A Aula 3 já entregou o "JÁ VALEU" (marco de resultado 1). A pessoa está satisfeita, sentindo que o método funciona. **Esta aula pega esse momento de satisfação e o redireciona pro produto:** "você viu o que consegue sozinho · agora deixa eu te mostrar pra onde isso vai quando você tem [o produto] do seu lado".

**Dois movimentos simultâneos:**

1. **Criar desejo pelo produto** — apresentar o produto inteiro (o que é · o que transforma · a vida com ele) de um jeito que a pessoa **queira** antes de saber o preço.
2. **Abrir a ficha de interesse** — medir quem está quente · qualificar antes do carrinho · separar morno de quente.

**Estado mental da entrada:**
- "Consegui um resultado bom essa semana. Mas e agora? Como vou longe com isso?"

**Estado mental da saída:**
- "Eu **quero** esse produto. Onde eu me inscrevo? Quanto custa?" ← a pergunta de preço fica em aberto de propósito até domingo

---

## 📢 Promessa da aula

> *"Hoje eu não vou te ensinar mais uma técnica. Hoje eu vou te mostrar **pra onde tudo isso que você aprendeu te leva** — e o caminho mais curto pra chegar lá. Fica até o fim, porque no final eu abro uma porta que eu só abro uma vez por turma."*

---

## 🧠 Avatar

### Entrada
- **Crença consolidada (vinda da Aula 3):** "o método funciona, eu já vi resultado"
- **Pergunta emergente:** "como eu levo isso adiante sem travar?"
- **Desejo latente:** quer o resultado maior, mas tem medo de fazer sozinho

### Saída
- **Nova crença:** "existe um caminho mais rápido e acompanhado — e eu quero ele"
- **Emoção dominante:** **desejo pelo produto** (não ansiedade de preço ainda)
- **Ação:** preenche a ficha de interesse

---

## 🎬 Hook de abertura (primeiros 60 segundos)

> "Bom dia, **{TRATAMENTO_PLURAL}**. Quarto dia. Olha quem ficou.
>
> Se você chegou até aqui, você já provou uma coisa pra você mesmo: **funciona**. Você viu {RESULTADO_DA_AULA_3} acontecer. Isso não foi sorte, foi método.
>
> Hoje a aula é diferente das outras. Eu não vim te ensinar mais uma técnica. Hoje eu vim te mostrar **pra onde isso vai** — o que acontece quando você para de tentar sozinho e passa a ter {NOME_PRODUTO} do seu lado.
>
> Presta atenção até o fim. Porque no final eu vou abrir uma coisa que eu só abro **uma vez por turma** — e é pra quem realmente quer o próximo nível."

---

## 📚 Blocos de conteúdo (roteiro · 100% produto)

> **Regra-mestra desta aula:** tudo gira em torno do produto. Mas **sem preço e sem bônus**. O objetivo é DESEJO, não decisão de compra. A decisão é domingo.

### Bloco 1 — A virada de chave (3-5 min)
- Recap rápido: "olha o que você já conquistou em 3 dias" (ancora o resultado da Aula 3)
- A virada: "mas tem uma diferença entre quem para aqui e quem vai longe"
- Nomeia a tensão: **fazer sozinho** (lento · solitário · tentativa e erro) vs **acompanhado** (rápido · seguro · com quem já fez)

### Bloco 2 — Apresentação do produto (8-12 min) ⭐
**O coração da aula.** Apresenta o {NOME_PRODUTO} por inteiro:

- **O que é:** {DEFINICAO_DO_PRODUTO} em uma frase clara
- **O que ele transforma:** o antes e o depois de quem entra
- **Como funciona na prática:** a jornada do aluno dentro do produto (sem detalhar preço/condição)
- **Pra quem é:** {PERFIL_CLIENTE_IDEAL}
- **Pra quem NÃO é:** {QUEM_NAO_DEVE_ENTRAR} ← filtra e aumenta desejo de quem se encaixa

> **Trava:** mostra os COMPONENTES e a TRANSFORMAÇÃO do produto, nunca a tabela de preço nem a lista de bônus. "Tudo isso eu detalho no domingo."

### Bloco 3 — Future pacing · a vida com o produto (5-7 min)
Leva a pessoa pra dentro do futuro dela **com** o produto:
- "Imagina daqui {PRAZO} você {RESULTADO_TRANSFORMADOR}"
- Pinta a cena concreta: rotina nova · resultado · como ela se sente · o que muda em volta
- Contrasta com o custo de continuar sozinha: "ou você continua mais {TEMPO} tentando descobrir sozinho"

### Bloco 4 — Prova: quem já fez (5-8 min)
**Estudos de caso narrativos** (nunca depoimento solto):
- "Como {NOME}, {IDADE}, {PROFISSAO}, conseguiu {RESULTADO_NUMERO_PRAZO} mesmo {OBSTACULO} usando o {NOME_PRODUTO}"
- 2-3 casos com perfil **parecido com a lead-tipo**
- Foco: "se funcionou pra alguém como você, funciona pra você"

> Detalhe do formato em `criador-paginas-low-ticket/references/estudo-de-caso-narrativo.md`.

### Bloco 5 — Abertura da ficha de interesse (3-5 min) ⭐
**Bloco crítico.** Sem isso, o domingo abre cego.

> "Então olha só. Eu não vou falar de valor hoje, nem de bônus, nem de condição. Isso tudo é no domingo, na última aula, onde eu abro o jogo completo.
>
> Mas hoje eu quero saber uma coisa: **quem aqui quer fazer parte disso?**
>
> Eu abri uma **ficha de interesse**. Não é compra, não é compromisso. É você me dizer 'eu quero o {NOME_PRODUTO}'. Quem preenche entra numa lista especial — e no domingo recebe o jogo completo em primeira mão.
>
> **Não é pra todo mundo.** É pra quem sentiu que quer o próximo nível. Link tá aqui 👇: **{LINK_FICHA_INTERESSE}**"

> **Trava:** a ficha mede DESEJO, não vende. Não cita preço nem bônus. A vantagem de preencher é "receber o jogo completo em primeira mão no domingo" (não bônus específico inventado).

---

## 🏆 Marco de vitória (marco de desejo)

**Não é marco de resultado** (esse foi na Aula 3). É **marco de desejo**: a pessoa sai querendo o produto.

**Sinal de sucesso:**
- Mensagens no chat tipo "como faço pra entrar?", "quanto custa?", "quero!"
- Ficha de interesse preenchida por ≥ 15% dos assistentes ao vivo
- Ficha de interesse ≥ 25% dos compradores até domingo

---

## 🌱 Seeding do produto

**Intensidade:** 🟠🟠🟠🟠 alta · **a aula é 100% produto**.

Diferente das outras aulas (onde o produto é mencionado de leve), aqui o produto **é o tema central**. Mas com 2 travas:
- ✅ Apresenta o produto inteiro · cria desejo · abre ficha
- ❌ **NÃO fala preço**
- ❌ **NÃO fala bônus**

Tudo isso fica reservado pro domingo (Aula 6 = pitch completo). Pode dizer: *"domingo às 20h eu abro tudo — valores, bônus, condições, garantia. Hoje é só pra você saber que existe e decidir se quer."*

---

## 🎣 Gancho da próxima aula

> "Amanhã, Aula 5. **{TEMA_AULA_5}**. A aula que fecha o ciclo de execução. Com ela você sai com **tudo na mão** pra rodar sozinho, se for o seu caminho.
>
> E no sábado, tira-dúvidas ao vivo. No domingo, **{HORARIO_PITCH}**, eu abro o jogo completo do {NOME_PRODUTO} — valores, bônus, condições, tudo.
>
> Se você quer o próximo nível, **preenche a ficha** 👆. Até amanhã."

---

## 📝 Tarefa para casa

**Nome:** Preencher ficha de interesse

**Passo a passo:**
1. Preenche a **ficha de interesse** → {LINK_FICHA_INTERESSE}
2. Responde com honestidade: você quer o {NOME_PRODUTO}?
3. Separa o domingo **{HORARIO_PITCH}** na agenda · é onde abre tudo
4. Prepara a pergunta que você quer fazer no tira-dúvidas de sábado

**Entregável esperado:** ficha preenchida · presença confirmada pro domingo.

---

## 📊 Métricas-alvo

| Métrica | Alvo |
|---|---|
| Retenção vs pico ao vivo da Aula 3 | ≥ 85% |
| Preenchimento ficha de interesse (na aula) | ≥ 15% dos assistentes |
| Preenchimento ficha de interesse (até domingo) | ≥ 25% dos compradores |
| Mensagens de desejo no chat ("quero", "quanto custa") | volume alto = aula funcionou |
| Compromisso com domingo declarado no chat | ≥ 20% |

---

## ✅ Checklist de pré-gravação

- [ ] Apresentação do produto pronta (o que é · transforma · pra quem · pra quem NÃO é)
- [ ] **ZERO menção a preço** revisada no roteiro
- [ ] **ZERO menção a bônus** revisada no roteiro
- [ ] 2-3 estudos de caso narrativos com perfil parecido com lead-tipo
- [ ] Future pacing concreto (cena da vida com o produto)
- [ ] Ficha de interesse testada (link funcionando · redirect OK)
- [ ] Bloco 5 (ficha) com tempo protegido (mínimo 3 min)
- [ ] Gancho do domingo claro ("domingo eu abro tudo")
- [ ] Aula não passa de 50 min

---

## 📎 Referências cruzadas

- Aula anterior: [`03-aula-3-automacao.md`](./03-aula-3-automacao.md) — o marco de resultado que alimenta o desejo
- Próxima aula: [`05-aula-5-trafego.md`](./05-aula-5-trafego.md) — fechamento técnico
- Pitch: [`06-aula-6-pitch.md`](./06-aula-6-pitch.md) — domingo · onde preço e bônus finalmente entram
- Estudo de caso narrativo: `criador-paginas-low-ticket/references/estudo-de-caso-narrativo.md`
- Mensageria da quinta: `mensageria-lpsg/SKILL.md` (coreografia pré-pitch · sem preço/bônus)
