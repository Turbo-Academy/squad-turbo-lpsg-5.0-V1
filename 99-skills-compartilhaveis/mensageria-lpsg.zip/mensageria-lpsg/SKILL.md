---
name: mensageria-lpsg
description: >
  Use esta skill sempre que o usuário quiser criar, estruturar, adaptar
  ou diagnosticar a mensageria de um lançamento pago semanal (LPSG).
  Trigger para: "mensageria do evento", "mensagens do grupo",
  "mensageria do lançamento", "roteiro de áudio", "script de mensagem",
  "templates da Meta", "WhatsApp template Utility", "fluxo de
  onboarding", "ficha de interesse mensagem", "carrinho aberto
  mensageria", "abertura de vendas D1", "mensagens do desafio",
  "adaptar mensageria", "coreografia de mensagens", "véspera do
  evento", "áudio da noite". A estrutura segue o **padrão aprovado**
  (Mensageria-LPSG · mentoria Léo Tabari × Matheus Dutra · 24/04/2026)
  com 7 fases · cada mensagem tem versão **Utility-ready** pra API
  oficial Meta (categoria UTILITY · variáveis {{1}}-{{N}} · URLs em
  botões · sample values reais · snake_case com prefixo lpsg_).
---

# Mensageria LPSG · padrão aprovado · Utility-ready

> **Fonte canônica:** `03-revisoes/Mensageria-LPSG-APROVADO.docx` (mentoria Léo Tabari × Matheus Dutra · 24/04/2026).
> Toda saída desta skill **deve respeitar a estrutura de 7 fases abaixo** e cada mensagem **deve ter versão Utility-ready** que passe na aprovação da Meta API oficial.

---

## REGRAS ABSOLUTAS DE OUTPUT

**REGRA 1** Toda mensagem tem 2 versões:
1. **Texto livre** (SendFlow / ManyChat / WhatsApp pessoal)
2. **Template Utility Meta API** (categoria `UTILITY`, variáveis `{{1}}-{{N}}`, URLs em botões, sample values reais)

**REGRA 2** Categoria sempre `UTILITY`. Marketing custa 10x mais e queima a lista.

**REGRA 3** URL **só em botão** · jamais inline no body. Se precisar 2 links, usar `BUTTONS: 2`.

**REGRA 4** Variáveis nomeadas em snake_case com prefixo `lpsg_` ou sigla do projeto. Ex: `lpsg_onboard_msg1`, `lpsg_aula_link`.

**REGRA 5** Sample values reais e plausíveis (não "Lorem ipsum" · não "{{name}}").

**REGRA 6** Nada de ALL CAPS · nada de múltiplos !!!. Reduz deliverability.

**REGRA 7** Bullets com hífen `-`, não `•`. Compatível com WhatsApp + SendFlow.

**REGRA 8** Reação `{EMOJI}` no fim do áudio é prova social visual dentro da API · sempre incluir.

**REGRA 9** "SAIR" (opt-out) **sempre visível no onboarding** (Msg 5 e 6) · reduz denúncia · protege o número.

**REGRA 10** 1 CTA por mensagem · link único vence link competindo.

---

## 7 FASES DO PADRÃO APROVADO

### FASE 1 · Onboarding (logo após a compra) · API oficial

6 mensagens triggered por **webhook Hotmart compra confirmada**. Espaçamento entre msgs respeitado · não disparar tudo de uma vez.

| # | Trigger | Função |
|---|---|---|
| Msg 1 | Compra confirmada | Confirmação de e-mail (botões SIM/NÃO) |
| Msg 2 | Após confirmação | Boas-vindas + cronograma do evento |
| Msg 3 | +30s | Passo 1: ficha de inscrição |
| Msg 4 | +2-3min | Passo 2: link do grupo WhatsApp |
| Msg 5 | +2-3min | Passo 3: pacto do "OK" + opção SAIR |
| Msg 6 | Fechamento | "Tamo junto" + lembrete véspera |

### FASE 2 · Véspera do evento · API oficial

| # | Quando | Formato | Função |
|---|---|---|---|
| Msg 7 | Domingo 19h | **Áudio ~1min30s** | Lembrete véspera + lacunas (fundamento, pontos, entrega) |

### FASE 3 · Durante o evento (Seg → Sex) · 4 mensagens por dia

| Letra | Horário | Função |
|---|---|---|
| Msg A diária | 10 min antes da aula | "Tá chegando" + teaser do dia |
| Msg B diária | No horário exato | "Começou! Entra agora" |
| Msg C diária | 12h | Replay do meio-dia + gancho de continuidade |
| Msg D diária | 20h-21h | **Áudio ~1min30s** · resumo + gancho próxima aula |

### FASE 4 · Quinta-feira · ficha de interesse

| # | Quando | Função |
|---|---|---|
| Msg extra (Qui 21h) | Após áudio normal da noite | Reforço da ficha + bônus exclusivos quem preenche até sábado |

### FASE 5 · Sábado · tira-dúvidas

| # | Quando | Função |
|---|---|---|
| Msg A | Sáb 9h30 | Convite tira-dúvidas (ZOOM/YouTube) |
| Msg B | Sáb 12h | Replay tira-dúvidas + chamada do pitch |

### FASE 6 · Domingo · pitch

| # | Quando | Formato | Função |
|---|---|---|---|
| Msg A | Dom 10h | **Áudio ~45s** | "Hoje é o dia" + promessa do pitch |
| Msg B | Dom 19h | Texto | "Começa em 1h" |
| Msg C | Dom horário do pitch | Texto | "Tá no ar" + link |

### FASE 7 · Segunda · abertura do carrinho

| # | Quando | Função |
|---|---|---|
| Msg A | Seg 6h45 | **Bônus dos 10 min** · só pra quem preencheu a ficha · bônus premium |
| Msg B | Seg horário das aulas (7h) | Abertura geral + bônus de primeira hora |
| Msg C | +3h após abertura | Bônus de 3h acabando |
| Msg D | Seg 20h | Primeiro dia acabando · valor sobe de R$X pra R$Y em 4h |

---

## Estrutura de referências

| Cenário | Reference |
|---|---|
| Templates Utility prontos pra Meta API | `references/utility-templates-meta.md` ⭐ |
| Onboarding completo (Fase 1) | `references/onboarding.md` |
| Véspera do evento (Fase 2) | `references/antecipacao-pre-evento.md` |
| Dia de aula (Fase 3) | `references/template-dia-de-aula.md` |
| Ficha de interesse (Fase 4) | `references/ficha-de-interesse.md` |
| Sábado tira-dúvidas (Fase 5) | `references/sabado-descompressao.md` |
| Domingo pitch (Fase 6) | `references/domingo-pitch.md` |
| Abertura de vendas D1 (Fase 7) | `references/abertura-vendas-d1.md` |
| Roteiros de áudio/vídeo | `references/roteiros-audio-video.md` |
| Variação de scripts, anti-repetição | `references/variacao-mensagens.md` |
| Regras e princípios | `references/regras-e-principios.md` |
| Checklist anti-IA | `references/checklist-anti-ia.md` |
| Template completo (master) | `references/template-completo-lpsg.md` |
| Exemplo CNC (manhã) | `references/exemplo-cnc.md` |
| Exemplo LPSG (manhã) | `references/exemplo-lpsg.md` |
| Exemplo Plantão Sem Medo (noite) | `references/exemplo-plantao.md` |

---

## Variáveis do template (canônicas)

```yaml
PROJETO:
  nome_especialista:        "{NOME_ESPECIALISTA}"          # Ex: Léo Tabari
  tratamento_plural:        "{TRATAMENTO_PLURAL}"          # Ex: tubos, guerreiros, traders
  nome_evento:              "{NOME_EVENTO}"                # Ex: Desafio LPSG
  nicho:                    "{NICHO}"                      # Ex: lançamento pago
  promessa_principal:       "{PROMESSA_PRINCIPAL}"         # Ex: construir seu lançamento em 7 dias
  emoji_reacao:             "{EMOJI}"                      # Ex: 🚀 (identidade do evento)

DATAS:
  dia_aula_1:               "{DIA_AULA_1}"                 # Ex: segunda, 12/05
  horario_aulas:            "{HORARIO_AULAS}"              # Ex: 7h da manhã
  horario_pitch:            "{HORARIO_PITCH}"              # Ex: 20h
  horario_tiraduvidas:      "{HORARIO_TIRADUVIDAS}"        # Ex: 10h
  horario_despertador:      "{HORARIO_DESPERTADOR}"        # Ex: 6h30

AULAS:
  tema_aula_1:              "{TEMA_AULA_1}"                # Fundamentos
  tema_aula_2:              "{TEMA_AULA_2}"
  tema_aula_3:              "{TEMA_AULA_3}"
  tema_aula_4:              "{TEMA_AULA_4}"
  tema_aula_5:              "{TEMA_AULA_5}"

LINKS:
  youtube_aulas:            "{LINK_YOUTUBE}"
  playlist:                 "{LINK_PLAYLIST}"
  ficha_inscricao:          "{LINK_FICHA_INSCRICAO}"
  grupo_whatsapp:           "{LINK_GRUPO}"
  ficha_interesse:          "{LINK_FICHA_INTERESSE}"
  checkout:                 "{LINK_CHECKOUT}"
  tiraduvidas_sabado:       "{LINK_TIRADUVIDAS}"

PREÇOS:
  valor_base:               "{VALOR_BASE}"                 # Ex: R$17.500
  valor_final:              "{VALOR_FINAL}"                # Ex: R$25.000
  bonus_premium:            "{BONUS_PREMIUM}"
  bonus_3h:                 "{BONUS_3H}"

PRODUTO:
  nome_produto_principal:   "{NOME_PRODUTO_PRINCIPAL}"
```

---

## Regras de aprovação Utility na Meta (não violar)

A Meta aprova templates Utility em **1-3 dias úteis** se respeitar:

```yaml
1_CATEGORY:        UTILITY (não MARKETING · não AUTHENTICATION)
2_NO_PROMOCAO:     Templates Utility NÃO podem ter ofertas/preços/CTAs de venda
                   → Para mensagens com preço/oferta (Fase 7 Msg D), ESCALAR para
                     MARKETING (custa mais mas é a única opção)
3_VARIAVEIS:       {{1}}, {{2}}, {{3}} numeradas · não nominais
4_LINKS:           Em BUTTONS apenas · nunca no body
5_SAMPLE_REAIS:    Cada {{N}} precisa de sample real · não "John Doe" / "exemplo"
6_LANGUAGE:        pt_BR · idioma travado
7_NO_ALL_CAPS:     "GARANTA AGORA" reprova · "Garanta agora" passa
8_NO_EXCESSO_EMOJI: 1-2 emojis OK · 5+ reprova
9_NO_HEADERS_LONGOS: Header (opcional) ≤ 60 caracteres
10_BODY_LIMITE:    1.024 caracteres máximo no body
11_FOOTER:         (opcional) ≤ 60 caracteres · sem variáveis
12_BUTTONS:        Máx 3 botões. Tipos: URL, PHONE, QUICK_REPLY
```

### Estratégia para a Fase 7 (carrinho com preço)

A Fase 7 Msg D tem `valor_base` e `valor_final` no body · isso é Marketing pela Meta. Caminhos:

1. **Marketing template aprovado** (custo maior · tempo aprovação igual)
2. **Utility template + body sem preço** + preço só no botão de checkout (mais barato · passa como Utility)
3. **Híbrido:** Msg D-aviso (Utility · sem preço) → quem clica vê o preço na página do checkout

> Recomendação: usar caminho 2 ou 3. A Meta tolera Utility com aviso de prazo · não tolera Utility com preço/desconto.

---

## Princípios de execução

1. **Padrão aprovado é canônico** · qualquer ajuste mantém as 7 fases.
2. **Toda mensagem tem versão Utility** · gerar as duas versões em paralelo.
3. **Sample values reais** · facilita aprovação e teste real.
4. **Áudios mantêm `{EMOJI}` no fim** · prova social visual.
5. **"SAIR" no onboard** · proteção do número WhatsApp.
6. **1 CTA por mensagem** · link único.
7. **Bullets com hífen** · compatibilidade.
8. **Sem ALL CAPS · sem !!! · sem 5+ emojis** · evita filtro spam.
9. **Categoria Utility por padrão** · escalar pra Marketing só quando obrigatório (preço/oferta no body).
10. **Versionamento de templates** · cada vez que aprovar uma versão, salvar `lpsg_xxx_v1`, `lpsg_xxx_v2`.

---

**Fonte:** `03-revisoes/Mensageria-LPSG-APROVADO.docx` · padrão validado · 24/04/2026.
