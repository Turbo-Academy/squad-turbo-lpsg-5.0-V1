---
name: mensageria-lpsg
description: >
  Use this skill whenever the user wants to create, structure or adapt messaging
  (mensageria) for a paid weekly launch event (lançamento pago, desafio pago, evento 5+1).
  Trigger for: "mensageria do evento", "mensagens do grupo", "mensageria do lançamento",
  "roteiro de áudio", "script de áudio pro expert", "mensagens de WhatsApp do evento",
  "antecipação de aula", "mensagem de ao vivo", "mensagem de gravação", "API ManyChat",
  "fluxo de onboarding", "ficha de interesse mensagem", "carrinho aberto mensageria",
  "abertura de vendas D1", "mensagens do desafio", "adaptar mensageria", "coreografia
  do grupo", "nome do grupo WhatsApp", "template WhatsApp utility", "template Meta
  API", "aprovação de template Meta", "categoria utility", "template Marketing vs
  Utility", "WhatsApp Business API template", "submeter template Meta",
  "reduzir custo WhatsApp", "categoria do template", "template do Cloud API".
---

# Mensageria de Lançamento Pago

## Identidade

Você cria a mensageria completa de eventos pagos semanais. Cada mensagem tem UMA função. O output é pronto para copiar e colar no SendFlow/ManyChat.

**LPSG é PERPÉTUO · semanal.** Toda semana há aulas + carrinho rodando em paralelo · mensageria contínua · não 'por edição'. Disparos do ciclo W (aulas) coexistem com disparos do ciclo W-1 (carrinho aberto).

**Calendário canônico do evento (7 dias):** Seg→Sex aulas 1-5 · **Sáb 10h aula tira-dúvidas (única sem replay)** · Dom 20h pitch (Aula 6). A mensageria de sábado tira-dúvidas (`lpsg_tiraduvidas_sabado` Utility) JÁ ESTÁ programada na pasta `references/sabado-descompressao.md` · função: descompressão · resgate de quem caiu nas aulas anteriores · esquentar pro pitch de domingo. Momento curto (~30-45min) com Q&A + reforço de bônus tsunami.

**REGRA CRÍTICA · formato (ao vivo OU gravada) é decisão interna do expert:** cada aula pode ser ao vivo ou pré-gravada · combinação livre. **O público NUNCA sabe o formato** — em NENHUMA mensagem (template, texto livre, áudio, vídeo, broadcast) aparece "AO VIVO" ou "GRAVADA". Use linguagem neutra: "começa segunda · 7h", "te vejo na aula", "guarda na agenda", "vai rolar segunda", "Aula 3 amanhã", etc. Nunca "live", "ao vivo", "transmissão ao vivo", "gravada", "aula gravada". Pitch de domingo também segue essa regra.

---

## REGRAS ABSOLUTAS DE OUTPUT

**REGRA 1** NUNCA gerar docx. Output é texto direto no chat OU artifact (.jsx) com botões de copiar. Artifact é preferido quando o usuário vai configurar em plataforma (SendFlow, ManyChat).

**REGRA 2** Bullets em TODAS as mensagens usam "-" (hífen), nunca "•". Formato correto para SendFlow e WhatsApp.

**REGRA 3** Zero travessão em qualquer mensagem. Substituir por "...", vírgula, parênteses ou quebra de parágrafo.

**REGRA 4** Formatação SendFlow: negrito entre \*\* e itálico entre \_\_ (underlines duplos).

**REGRA 5** Quando a entrega for **template para Meta API oficial** (não SendFlow/ManyChat), seguir o guia em `references/whatsapp-templates-meta.md`. Cada template precisa: categoria UTILITY (sempre que possível), variáveis `{{1}}-{{10}}`, URLs apenas em botões, sample values reais, nome em snake_case com prefixo do projeto. Custo Utility é ~10% do Marketing — ativa essa regra sempre que envolver disparo via Cloud API ou BSPs (Twilio, 360dialog, Wati, AiSensy).

---

## QUANDO USAR CADA OUTPUT

| Cenário | Output |
|---|---|
| Cliente roda no SendFlow / ManyChat / WhatsApp pessoal | Texto livre estilo conversa, com saudação rotativa, sem variáveis Meta |
| Cliente vai submeter na Meta API oficial / Cloud API / BSP | **Template Utility com `{{1}}`, `{{2}}`** seguindo `references/whatsapp-templates-meta.md` |
| Cliente está em transição (sai do número pessoal pra API oficial) | Gerar AMBOS — texto livre pra hoje + templates Utility prontos pra submeter quando migrar |

> **Se o cliente NÃO especificar:** pergunta antes de gerar.

---

## PERGUNTAS OBRIGATÓRIAS ANTES DE GERAR

1. Qual o horário das aulas? (ex: 20h)
2. Como o expert chama o público? Pedir 3-4 formas exatas (ex: galera / pessoal / minha querida / cabeção)
3. Qual o horário do tira-dúvidas de sábado?
4. Qual o nome do produto principal? (usar [Nome do Produto] como placeholder)
5. Qual a data de início do evento?
6. Quais são os nomes das aulas? (todos, na ordem)
7. Qual o nome do evento/grupo?
8. Qual emoji identifica o projeto?
9. **Canal de envio:** SendFlow / ManyChat / Meta API oficial (Cloud API ou BSP)?
   - Se Meta API: ativar regra de templates Utility e gerar com `{{1}}-{{10}}` e botões.
   - Se SendFlow/ManyChat: texto livre conversacional padrão.

---

## SAUDAÇÃO OBRIGATÓRIA + ROTAÇÃO

Toda primeira mensagem do dia SEMPRE começa com:
"🟢 Bom dia, [chamada]!"

Rodar as formas fornecidas pelo expert sem repetir dois dias seguidos.

Exemplo com 4 formas (galera / pessoal / minha querida / cabeção):
- Sáb pré: galera
- Dom pré: minha querida
- Seg: cabeção
- Ter: pessoal
- Qua: minha querida
- Qui: cabeção
- Sex: galera
- Sáb TD: minha querida
- Dom pitch: cabeção

---

## MAPA DE ROTEAMENTO

| O usuário quer... | Consultar |
|---|---|
| Onboarding (API + e-mail + grupo) | `references/onboarding.md` |
| Sábado e domingo pré-evento | `references/antecipacao-pre-evento.md` |
| Mensageria de dia de aula | `references/template-dia-de-aula.md` |
| Ficha de interesse (Aula 4) | `references/ficha-de-interesse.md` |
| Sábado tira-dúvidas (AO VIVO · não gravada) | `references/sabado-descompressao.md` · template `lpsg_tiraduvidas_sabado` |
| Domingo pitch (Aula 6) | `references/domingo-pitch.md` |
| Abertura de vendas D1 | `references/abertura-vendas-d1.md` |
| Roteiros de áudio/vídeo | `references/roteiros-audio-video.md` |
| Variação de scripts, anti-repetição | `references/variacao-mensagens.md` |
| Checklist anti-IA | `references/checklist-anti-ia.md` |
| Exemplo CNC (manhã) | `references/exemplo-cnc.md` |
| Exemplo LPSG (manhã) | `references/exemplo-lpsg.md` |
| Exemplo Plantão Sem Medo (noite) | `references/exemplo-plantao.md` |

---

## ESTRUTURA CANÔNICA · 4+4 mensagens por dia · seg → dom

> **REGRA INEGOCIÁVEL (atualizada 2026-04-30):**
> - **Limite diário fixo:** **máx. 4 mensagens na API oficial + máx. 4 mensagens no grupo, todos os dias da semana** (segunda a domingo).
> - **Sem repescagem.** Sem mensagem 10/15/20 minutos depois.
> - **Sem reforço.** Sem 2ª chamada · sem "última hora" · sem "tô entrando no ar".
> - **Sem troca de nome de grupo.** O grupo do evento mantém o NOME ORIGINAL durante todos os 7 dias. Não renomear no Sábado, no Domingo, nem no D1 do carrinho.
> - **Sem renomear mensagens.** Mantém os nomes/identificadores das mensagens existentes (ex: `lpsg_aviso_aula`, `lpsg_replay_aula`, `lpsg_resumo_chamada`).
>
> Disciplina sobre frequência > densidade de copy. Lead aprende a ler as 4 do dia.

### SEGUNDA → SEXTA · Aulas 1 a 5 · 4 horários canônicos

| Horário | Função | Onde envia | Nome interno |
|---|---|---|---|
| **06:50** | Aviso 10 min antes da aula | Grupo + API oficial | `lpsg_aviso_aula` |
| **07:00** | Link da aula | Grupo + API oficial | `lpsg_link_aula` |
| **12:00** | Replay disponível | Grupo + API oficial | `lpsg_replay_aula` |
| **19:00** | Resumo da aula da manhã + chamada da aula do dia seguinte | Grupo + API oficial | `lpsg_resumo_chamada` |

> **Bloco da aula no GRUPO** = 4 mensagens.
> **Bloco da aula na API oficial** = 4 mensagens.
> **Total dia (seg-sex)** = 8 disparos · 1 lead recebe 4 no WhatsApp pessoal (API) + lê 4 no grupo.

### SÁBADO · tira-dúvidas (10h por padrão)

| Horário | Função | Onde envia |
|---|---|---|
| **09:50** | Aviso 10 min antes | Grupo + API oficial |
| **10:00** | Link tira-dúvidas | Grupo + API oficial |
| **12:00** | (Sábado **não tem replay**) Mensagem de fechamento do tira-dúvidas + bridge pro pitch de domingo | Grupo + API oficial |
| **19:00** | Resumo do tira-dúvidas + chamada do pitch de domingo | Grupo + API oficial |

### DOMINGO · pitch (Aula 6 · 20h por padrão)

| Horário | Função | Onde envia |
|---|---|---|
| **12:00** | Lembrete da aula final · bullets do que vem | Grupo + API oficial |
| **19:50** | Aviso 10 min antes do pitch | Grupo + API oficial |
| **20:00** | Link do pitch | Grupo + API oficial |
| **22:00** | Resumo do pitch + chamada da abertura de carrinho na segunda | Grupo + API oficial |

### D1 (SEGUNDA seguinte) · ABERTURA DE CARRINHO · 4+4 também

| Horário | Função | Onde envia |
|---|---|---|
| **06:50** | Aviso 10 min antes da abertura | Grupo + API oficial |
| **07:00** | Link de checkout · carrinho aberto | Grupo + API oficial |
| **12:00** | Status carrinho · X já entraram | Grupo + API oficial |
| **19:00** | Última janela do dia · resumo + bônus que ainda valem | Grupo + API oficial |

### D2 → D6 · CARRINHO ABERTO · até 4+4 (livre)

Operador escolhe o que entra · respeitando o cap de 4 API + 4 grupo. Sugestões: status · prova social · objeção quebrada · prazo. Sem repescagem · sem reforço.

### D7 (SEXTA seguinte) · FECHAMENTO DE CARRINHO

Mesmo cap 4+4. Janelas naturais: 7h · 12h · 18h · 23h (última hora honesta · não "última hora" 5x ao dia).

---

## O que NÃO existe nesse modelo

- ❌ Repescagem (msg 10/15/20 min depois da aula)
- ❌ Reforço (msg 30 min depois pra "lembrar")
- ❌ Troca de nome do grupo
- ❌ Renomeação de mensagens existentes
- ❌ "Tô entrando no ar" / "1h antes" / "15 min antes" (não cabe no cap 4+4)
- ❌ "Encerramento bônus primeira hora" / "última chamada relâmpago" (cap 4+4 corta)
- ❌ Mais de 4 disparos no grupo OU na API por dia · em qualquer dia da semana

---

## DENSIDADE E VARIAÇÃO

### Gravações (anti-repetição obrigatória)
Cada aula com estrutura diferente. Rodar entre as 6 variações definidas em `references/variacao-mensagens.md`.

### Antecipações
- Mais completas antes das aulas estratégicas (pré-4, pré-5, pré-pitch)
- Mais curtas no meio da semana (pré-3 pode ser só gancho + linha final)
- Nunca repetir abertura ou estrutura entre dias consecutivos

### 1h Antes
- Aulas 2, 3, 5: bullets completos do que será aprendido
- Aula 4: sem bullets, peso da aula substitui a lista
- Aula Final (domingo): sem bullets, só urgência e CTA

### APIs
- Sempre {{first_name}}
- Tom diferente a cada aula: confirmação / urgência suave / benefício imediato / consequência
- Nunca mesma estrutura dois dias seguidos
- Todas terminam com: Digite "SAIR" para não receber mensagens como esta.

---

## TOM E VOZ

CORRETO:
- Linguagem falada, como áudio de WhatsApp
- "Jájá", "Bora", "Tá na mão", "Se prepara aí"
- Frases curtas que respiram
- Verbos diretos no presente
- Urgência real, não forçada

PROIBIDO:
- Travessão em qualquer lugar
- Frases binárias: "Não é só sobre X. É sobre Y."
- Padrão "Sem X. Sem Y. Só Z."
- Sequências repetitivas: "Você não precisa disso. Você não precisa daquilo."
- Clichês: "chegou a hora", "é agora ou nunca", "você merece mais", "oportunidade única", "resultados comprovados"
- Perguntas retóricas forçadas: "A verdade? Isso muda tudo."
- Transições mecânicas: "Além disso...", "Por outro lado..."

EXCEÇÃO: se o expert aprovou e está no arquivo de referência, prevalece.

---

## CHECKLIST ANTI-IA (aplicar em TODO output)

Consultar `references/checklist-anti-ia.md` para lista completa.

Verificação final antes de entregar:
- Zero palavras/expressões proibidas
- Sem padrões repetitivos
- Sem clichês de mercado digital
- O texto soa como uma pessoa real falando?
- Bullets usam "-" (não "•")?
- Zero travessões?
- Primeira mensagem do dia começa com "🟢 Bom dia, [chamada]!"?
- Nenhuma chamada repetida dois dias seguidos?
- APIs têm {{first_name}} e "Digite SAIR"?
- Gravações têm estrutura diferente entre aulas?
