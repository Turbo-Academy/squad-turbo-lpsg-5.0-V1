# Templates Utility · padrão aprovado · prontos pra Meta API oficial

> Cada template do padrão aprovado em **2 versões**: `BODY` para Meta API (UTILITY) + `TEXTO LIVRE` (SendFlow / ManyChat / WhatsApp pessoal).
>
> **Categoria padrão:** `UTILITY`. Quando obrigatório `MARKETING` (preço/oferta no body), está sinalizado.
>
> **Variáveis:** `{{1}}` a `{{N}}` numeradas. **Sample values reais** abaixo de cada template (necessários pra aprovação Meta).
>
> **Idioma:** `pt_BR` (travado).
> **Limite body:** 1.024 caracteres. **Header (opcional):** ≤ 60. **Footer:** ≤ 60.

---

## FASE 1 · Onboarding (6 mensagens)

### `lpsg_onboard_msg1_confirmacao_email` · UTILITY

**Quando:** webhook Hotmart compra confirmada.

**BODY:**
```
Oi! Aqui é o {{1}} 👋

Acabou de chegar sua compra do {{2}}. Já te coloquei na nossa lista.

Antes de continuar, me confirma uma coisa rapidinho: você comprou com o e-mail {{3}}, tá certo?
```

**BUTTONS:** 2 (Quick Reply)
- `Sim, é esse` (payload: `email_ok`)
- `Não, é outro` (payload: `email_diferente`)

**Sample values:**
- `{{1}}` = `Léo Tabari`
- `{{2}}` = `Desafio LPSG`
- `{{3}}` = `joao.silva@gmail.com`

---

### `lpsg_onboard_msg2_boas_vindas` · UTILITY

**Quando:** após `email_ok` da Msg 1.

**BODY:**
```
Perfeito. Então bora alinhar tudo.

O evento começa {{1}}, às {{2}} (sim, cedo, mas é importante começar logo cedo pra você render o dia inteiro depois).

📅 Seg a Sex às {{2}}
🎯 Domingo às {{3}} (aula do pitch)

Agora eu preciso que você faça 3 coisas rápidas pra garantir que nada se perca no caminho. Vou te mandar uma de cada vez.
```

**Sample values:**
- `{{1}}` = `segunda, 12/05`
- `{{2}}` = `7h da manhã`
- `{{3}}` = `20h`

---

### `lpsg_onboard_msg3_ficha_inscricao` · UTILITY

**Quando:** +30s da Msg 2.

**BODY:**
```
1️⃣ Primeiro passo: sua ficha de inscrição.

São 2 minutinhos. É por ela que eu sei quem você é e te mando as coisas certas na hora certa. Sem ficha, nada anda.
```

**BUTTONS:** 1 (URL)
- `Preencher ficha` → `{{1}}` (sample: `https://lpsg.example.com/ficha`)

---

### `lpsg_onboard_msg4_grupo_whatsapp` · UTILITY

**Quando:** +2-3min da Msg 3.

**BODY:**
```
2️⃣ Segundo passo: entra no grupo do WhatsApp.

Esse grupo é o backup oficial do evento. Se o WhatsApp resolver bloquear meu número aqui (acontece), eu mando tudo lá. Você não pode ficar de fora.
```

**BUTTONS:** 1 (URL)
- `Entrar no grupo` → `{{1}}` (sample: `https://chat.whatsapp.com/abc123xyz`)

---

### `lpsg_onboard_msg5_pacto_ok` · UTILITY

**Quando:** +2-3min da Msg 4.

**BODY:**
```
3️⃣ Terceiro passo, combinado importante.

Toda vez que eu te mandar mensagem aqui, me responde só com um "OK".

Parece bobagem, mas é assim que o WhatsApp entende que você quer receber e não me bloqueia. Sem isso, metade das pessoas perde metade das aulas.

E se a qualquer momento você quiser parar de receber, manda "SAIR" que eu paro na mesma hora. Sem drama.
```

**BUTTONS:** 1 (Quick Reply)
- `OK` (payload: `pacto_ok`)

---

### `lpsg_onboard_msg6_fechamento` · UTILITY

**Quando:** após `pacto_ok` da Msg 5.

**BODY:**
```
Prontinho ✅

Qualquer dúvida até {{1}}, é só me chamar aqui. Domingo à noite eu te mando um áudio com o último lembrete antes da gente começar.

Tamo junto. {{2}}
```

**Sample values:**
- `{{1}}` = `segunda, 12/05`
- `{{2}}` = `🚀`

---

## FASE 2 · Véspera do evento

### `lpsg_vespera_audio` · UTILITY (com mídia AUDIO)

**Quando:** Domingo 19h.

**HEADER:** `AUDIO` (anexar arquivo de áudio gravado · ~1min30s)

**BODY (mensagem complementar ao áudio):**
```
Áudio de {{1}}, {{2}}.

Amanhã a gente começa: {{3}}, {{4}}.

Aula 1 do {{5}}, ao vivo.

Ouve com atenção. Te vejo amanhã. {{6}}
```

**Sample values:**
- `{{1}}` = `1 minuto`
- `{{2}}` = `Léo Tabari`
- `{{3}}` = `segunda, 12/05`
- `{{4}}` = `7h da manhã`
- `{{5}}` = `Desafio LPSG`
- `{{6}}` = `🚀`

> **Roteiro do áudio** (gravar com lacunas preenchidas) em `references/antecipacao-pre-evento.md`.

---

## FASE 3 · Durante o evento (Seg → Sex · 4 msgs/dia)

### `lpsg_aula_aviso_10min` · UTILITY (Msg A diária)

**Quando:** 10 minutos antes da aula.

**BODY:**
```
Bom dia! ☕

Em 10 minutos a gente começa a Aula {{1}}: {{2}}.

{{3}}
```

**BUTTONS:** 1 (URL)
- `Entrar na aula` → `{{4}}` (sample: `https://youtube.com/live/abc123`)

**Sample values:**
- `{{1}}` = `1`
- `{{2}}` = `Fundamentos do LPSG`
- `{{3}}` = `Hoje é o dia dos fundamentos. Sem isso, nada depois faz sentido.`
- `{{4}}` = `https://youtube.com/live/abc123`

---

### `lpsg_aula_link_no_horario` · UTILITY (Msg B diária)

**Quando:** No horário exato da aula.

**BODY:**
```
Começou! Entra agora.
```

**BUTTONS:** 1 (URL)
- `Entrar agora` → `{{1}}` (sample: `https://youtube.com/live/abc123`)

---

### `lpsg_aula_replay_meio_dia` · UTILITY (Msg C diária)

**Quando:** 12h.

**BODY:**
```
Se você não conseguiu ver de manhã, agora é a hora.

Senta {{1}} no almoço e assiste pelo replay.

{{2}}
```

**BUTTONS:** 1 (URL)
- `Assistir replay` → `{{3}}` (sample: `https://youtube.com/playlist?list=PLxxx`)

**Sample values:**
- `{{1}}` = `40 minutos`
- `{{2}}` = `Amanhã tem mais, mas sem hoje, amanhã não faz sentido.`
- `{{3}}` = `https://youtube.com/playlist?list=PLxxx`

---

### `lpsg_aula_audio_noite` · UTILITY (Msg D diária · com mídia AUDIO)

**Quando:** 20h-21h.

**HEADER:** `AUDIO` (~1min30s)

**BODY:**
```
Áudio do dia, {{1}}.

Amanhã, {{2}}, mesmo canal: Aula {{3}}, {{4}}.

{{5}}
```

**Sample values:**
- `{{1}}` = `Léo Tabari`
- `{{2}}` = `7h da manhã`
- `{{3}}` = `2`
- `{{4}}` = `Construção da máquina`
- `{{5}}` = `🚀`

---

## FASE 4 · Quinta · ficha de interesse

### `lpsg_quinta_ficha_reforco` · UTILITY

**Quando:** Quinta 21h, após áudio normal.

**BODY:**
```
Ah, e quem esteve na aula hoje já viu: abri a ficha de interesse pra galera que quer dar o próximo passo e entrar no {{1}}.

Se você ainda não preencheu, preenche agora.

Quem preenche até sábado garante bônus exclusivos na abertura, bônus que quem não preencheu não vai ter acesso, mesmo comprando depois.

Não é ameaça, é regra do jogo.
```

**BUTTONS:** 1 (URL)
- `Preencher ficha` → `{{2}}` (sample: `https://lpsg.example.com/ficha-interesse`)

**Sample values:**
- `{{1}}` = `Acelerador Turbo`
- `{{2}}` = `https://lpsg.example.com/ficha-interesse`

---

## FASE 5 · Sábado · tira-dúvidas

### `lpsg_sabado_tiraduvidas_convite` · UTILITY

**Quando:** Sáb 9h30.

**BODY:**
```
Bom dia!

Hoje às {{1}} eu abro meu {{2}} pra tirar dúvidas de verdade. Se você mandou pergunta na ficha, pode cair a sua.

{{3}} de tira-dúvidas. Vai valer.
```

**BUTTONS:** 1 (URL)
- `Entrar no tira-dúvidas` → `{{4}}` (sample: `https://zoom.us/j/abc123`)

**Sample values:**
- `{{1}}` = `10h`
- `{{2}}` = `Zoom`
- `{{3}}` = `1 hora`
- `{{4}}` = `https://zoom.us/j/abc123`

---

### `lpsg_sabado_replay_tiraduvidas` · UTILITY

**Quando:** Sáb 12h.

**BODY:**
```
Se perdeu o tira-dúvidas de hoje cedo, tá gravado.

Amanhã é o pitch. Não perde.
```

**BUTTONS:** 1 (URL)
- `Ver gravação` → `{{1}}` (sample: `https://youtube.com/playlist?list=PLxxx`)

---

## FASE 6 · Domingo · pitch

### `lpsg_pitch_audio_manha` · UTILITY (com mídia AUDIO)

**Quando:** Dom 10h.

**HEADER:** `AUDIO` (~45s)

**BODY:**
```
Áudio de {{1}}.

Hoje, {{2}}, eu abro meu jogo. Aqui mesmo.
```

**Sample values:**
- `{{1}}` = `Léo Tabari`
- `{{2}}` = `20h`

---

### `lpsg_pitch_1h_antes` · UTILITY

**Quando:** Dom 19h (1h antes do pitch).

**BODY:**
```
Em 1 hora a gente começa.

Hoje é diferente. Hoje eu te entrego tudo.
```

**BUTTONS:** 1 (URL)
- `Lembrete da aula` → `{{1}}` (sample: `https://youtube.com/live/pitch-abc`)

---

### `lpsg_pitch_no_ar` · UTILITY

**Quando:** Dom no horário do pitch.

**BODY:**
```
Tá no ar. {{1}}
```

**BUTTONS:** 1 (URL)
- `Entrar agora` → `{{2}}` (sample: `https://youtube.com/live/pitch-abc`)

**Sample values:**
- `{{1}}` = `🚀`
- `{{2}}` = `https://youtube.com/live/pitch-abc`

---

## FASE 7 · Segunda · abertura do carrinho

> ⚠️ **Atenção Meta:** Msgs com preço/desconto explícito no body podem reprovar como UTILITY. Estratégias:
>
> - **Caminho A** (recomendado): texto Utility-friendly + preço só na página de destino (no botão).
> - **Caminho B:** submeter como `MARKETING` (custa 10x mais).
>
> Templates abaixo seguem o **Caminho A** · sem preço no body.

### `lpsg_carrinho_msg_a_bonus_10min` · UTILITY (segmentado · só ficha)

**Quando:** Seg 6h45 · só pra quem preencheu ficha de interesse.

**BODY:**
```
Bom dia!

Como combinado, quem preencheu a ficha tem acesso antecipado. O carrinho abre agora pra você, com bônus exclusivos dos 10 primeiros minutos.

Às {{1}} em ponto abre pro resto. Você tem 15 minutos de vantagem.
```

**BUTTONS:** 1 (URL)
- `Garantir acesso antecipado` → `{{2}}` (sample: `https://pay.hotmart.com/xxx?utm_source=ficha`)

**Sample values:**
- `{{1}}` = `7h`
- `{{2}}` = `https://pay.hotmart.com/xxx?utm_source=ficha`

---

### `lpsg_carrinho_msg_b_abertura_geral` · UTILITY

**Quando:** Seg horário das aulas (7h).

**BODY:**
```
Tá aberto pra todo mundo. 🔥

Bônus de primeira hora rodando agora.
```

**BUTTONS:** 1 (URL)
- `Entrar agora` → `{{1}}` (sample: `https://pay.hotmart.com/xxx`)

---

### `lpsg_carrinho_msg_c_3h_acabando` · UTILITY

**Quando:** Seg 3h após abertura geral (10h).

**BODY:**
```
Bônus de 3 horas acabando daqui a pouco.

Quem entrar até {{1}} leva o bônus extra.
```

**BUTTONS:** 1 (URL)
- `Garantir o bônus` → `{{2}}` (sample: `https://pay.hotmart.com/xxx`)

**Sample values:**
- `{{1}}` = `10h`
- `{{2}}` = `https://pay.hotmart.com/xxx`

---

### `lpsg_carrinho_msg_d_primeiro_dia` · UTILITY

**Quando:** Seg 20h.

**BODY (sem preço · Caminho A):**
```
Em 4 horas o bônus de primeiro dia encerra.

Depois disso o valor sobe.

Se faz sentido pra você, é agora.
```

**BUTTONS:** 1 (URL)
- `Ver oferta completa` → `{{1}}` (sample: `https://pay.hotmart.com/xxx`)

> **Caminho B (Marketing):** se quiser preço no body, submeter como MARKETING:
>
> ```
> Em 4 horas o bônus encerra. Depois disso o valor sobe de {{1}} pra {{2}}.
> A diferença {{3}}.
>
> [BUTTON] Ver oferta → {{4}}
>
> sample: {{1}}=R$17.500 · {{2}}=R$25.000 · {{3}}=paga 6 meses de gestor · {{4}}=https://...
> ```

---

## Workflow de aprovação Meta

```
1. Submeter cada template em https://business.facebook.com/wa/manage/message-templates/
2. Preencher:
   - Name: lpsg_xxx (snake_case · prefixo)
   - Category: UTILITY (recomendado) OU MARKETING (Fase 7 D · Caminho B)
   - Language: Portuguese (Brazil) → pt_BR
   - Header: opcional (TEXT · IMAGE · VIDEO · DOCUMENT · AUDIO)
   - Body: copiar do template acima · com {{N}}
   - Footer: opcional · sem variáveis
   - Buttons: copiar do template acima
3. Adicionar SAMPLE VALUES (cada {{N}} precisa de sample real)
4. Submeter · Meta retorna em 1-3 dias úteis
5. Status:
   - APPROVED: pronto pra disparar
   - PENDING: aguardando review
   - REJECTED: ajustar e ressubmeter
```

### Erros comuns de reprovação

| Motivo | Fix |
|---|---|
| `Body contains promotional content` | Tirar preço/desconto/oferta do body · escalar pra MARKETING |
| `Variable parameters not properly used` | Cada {{N}} precisa de contexto · sem variáveis "soltas" |
| `Missing sample values` | Preencher TODOS os samples antes de submeter |
| `Excessive use of emojis` | Reduzir pra 1-2 emojis no body |
| `URL in body` | Mover URL pra BUTTONS · obrigatório |
| `ALL CAPS detected` | Trocar pra Title Case ou minúsculas |

---

## Checklist antes de submeter

```
[ ] Categoria correta (UTILITY default · MARKETING só se preço/oferta)
[ ] Variáveis {{N}} numeradas · todas com sample value real
[ ] Idioma = pt_BR
[ ] URL apenas em BUTTONS
[ ] Body ≤ 1.024 caracteres
[ ] Header (se houver) ≤ 60 caracteres
[ ] Footer (se houver) ≤ 60 caracteres · sem variáveis
[ ] Sem ALL CAPS · sem !!! · sem 5+ emojis
[ ] Bullets com hífen "-" se houver
[ ] Snake_case com prefixo "lpsg_" no name
[ ] Versionamento: lpsg_xxx_v1, _v2 etc · não sobrescrever aprovados
```

---

**Fonte canônica:** `03-revisoes/Mensageria-LPSG-APROVADO.docx` · padrão validado · 24/04/2026.
