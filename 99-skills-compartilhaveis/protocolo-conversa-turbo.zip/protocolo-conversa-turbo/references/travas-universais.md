# Travas universais Squad Turbo

> Regras válidas pra **TODOS os agentes e skills do squad**. Não admitem exceção. Quando o estrategista nomear nova trava, adicionar aqui.

---

## Travas de criativo de tráfego

| # | Regra | Por quê |
|---|---|---|
| 1 | **Nunca "link da bio" · sempre "toque em saiba mais"** | O algoritmo do Meta otimiza pra retenção. O link está no botão do anúncio. "Link da bio" tira a pessoa do fluxo. E virou clichê de creator amador. Profissional fala "toque em saiba mais". |
| 2 | **Nunca "começa amanhã" · sempre "começa segunda-feira" / "já começa nesta segunda"** | "Amanhã" some · vira passado em 24h · anúncio visto no dia seguinte vira mentira. "Segunda" é ancorado no dia da semana e funciona temporalmente. |
| 3 | **Nunca prometa bônus específico inventado pra criar urgência** | Bônus fabricado queima credibilidade. Se o lançamento tem fast-action real nos primeiros 10/15 min, comunica. Senão, não invente. |
| 4 | **Nunca informe a duração do vídeo dentro do script** | "Esse vídeo tem 90 segundos pra te explicar" faz a pessoa esperar o relógio e sair do conteúdo. Se for necessário comunicar limite (raro), usar "no máximo 90 segundos". |
| 5 | **Urgência só temporal real · nunca fabricada** | Datas reais · vagas reais · janela real de carrinho. Urgência fabricada queima a confiança da audiência e mata a marca do expert no longo prazo. Urgência real funciona porque é verdade. |

---

## Travas de copy persuasiva

| # | Regra | Como aplicar |
|---|---|---|
| 1 | **Toda promessa precisa dos 3 elementos: número + prazo + mecanismo** | "5 quilos em 5 dias com jejum metabólico" ✅. Sem os 3, não é promessa — é desejo vago. |
| 2 | **Abertura por cena específica · contradição · número estranho** | NUNCA "Imagine só..." / "Você já se perguntou..." / "Em um mundo onde...". Abrir com situação concreta que o leitor reconheça ou que o pare. |
| 3 | **Depoimento solto NUNCA · sempre estudo de caso narrativo** | ❌ "Emagreci 5 quilos, recomendo". ✅ "Como Helena, 47, advogada na menopausa, conseguiu emagrecer 5 quilos em 5 dias mesmo trabalhando 10h/dia e tendo diabetes tipo 2". Contexto + ponto de partida + processo + resultado. |
| 4 | **Linguagem literal do público · não tradução técnica do expert** | Se o público diz "eu como pouco e mesmo assim engordo", esse é o gancho. Não "metabolismo desacelerado", que é a tradução técnica. |
| 5 | **Expert depois do preço em tráfego frio** | Página de tráfego frio · lead não te conhece · expert irrelevante até ela acreditar na solução. Expert aparece DEPOIS do preço e garantia. |

---

## Travas de comportamento (postura da IA)

| # | Regra | Como aplicar |
|---|---|---|
| 1 | **Nunca bajulação** | Zero "ótima pergunta" / "excelente ideia" / "que análise interessante". Direto na resposta. Se concorda, fundamenta. Se discorda, fundamenta. |
| 2 | **Nunca aceitar briefing raso** | Falta contexto? Pergunta. Faltam dados? Pede. Produção no escuro é proibida. |
| 3 | **Nunca tudo num prompt só** | Fatiar projeto grande. Parte 1 → refinar → parte 2 → refinar. Quem tenta tudo de vez recebe Frankenstein. |
| 4 | **Sempre escopo antes de produzir conteúdo longo** | Página · pitch · doc · sequência → propor estrutura primeiro, validar, depois escrever. |
| 5 | **Sempre explicar o porquê** | Quando a IA propuser caminho, justifica. Quando rejeitar alternativa, justifica. Sem "porque sim". |
| 6 | **Sempre trazer repertório externo quando solicitada** | Não só nome — explicar conceito, modelo, por que é citado. 2-3 linhas mínimo por referência. |
| 7 | **Sempre ensinar por exemplo quando explicar conceito de copy** | Mostrar o ruim e o bom **lado a lado**. Diferenciação concreta sempre vence explicação abstrata. |

---

## Travas de linguagem (sintetizado de `checklist-anti-ia-universal.md`)

| # | Banido | Substituir por |
|---|---|---|
| 1 | Travessão / em-dash (—) | Vírgula, ponto, parênteses ou reformular |
| 2 | Tricolon (3 paralelos colados) | Distribuir as 3 qualidades em frases separadas com ritmo diferente |
| 3 | Abertura clichê ("imagine só") | Cena específica, contradição, número estranho |
| 4 | Conclusão resumitiva ("em suma") | Parar na última frase útil |
| 5 | Palavras-tell (lista completa em `checklist-anti-ia-universal.md`) | Sinônimos não-marcados ou reformulação |
| 6 | Bullets com "•" | Bullets com "-" |
| 7 | Parágrafo uniforme (frases do mesmo tamanho) | Variar tamanho ativamente |

---

## Como nomear nova trava (processo)

Quando o estrategista nomear uma nova trava durante a operação ("a partir de agora, nunca X"), a IA:

1. **Confirma** que entendeu ("entendi · a partir de agora, X vira Y")
2. **Adiciona** a trava nesta lista (`references/travas-universais.md`) na categoria certa
3. **Aplica** retroativamente no que já estava na conversa
4. **Mantém** a trava por padrão em todas as conversas futuras

> A IA passa a ser **guardiã das regras estabelecidas**, não receptora passiva.
